export const sliderItems=[
    {
        id:1,
        img: "https://www.teahub.io/photos/full/94-940152_dell-laptop-png-background-image-laptop-photo-high.png",
        title: "Dell XPS Series 13''",
        desc: "Nostrud nulla aliquip deserunt deserunt ullamco ex nulla pariatur. Veniam et ea sint reprehenderit quis aute amet incididunt Lorem sunt cupidatat ipsum incididunt eiusmod. Occaecat incididunt incididunt aliqua occaecat enim laborum fugiat voluptate occaecat occaecat amet dolore.",
        bg:"fcf1ed",
    },
    {
        id:2,
        img: "https://assets.materialup.com/uploads/b8c09f81-df2d-4d81-bd95-58fa1413063d/preview.png",
        title: "Hostel Sale",
        desc: "Nostrud nulla aliquip deserunt deserunt ullamco ex nulla pariatur. Veniam et ea sint reprehenderit quis aute amet incididunt Lorem sunt cupidatat ipsum incididunt eiusmod. Occaecat incididunt incididunt aliqua occaecat enim laborum fugiat voluptate occaecat occaecat amet dolore.",
        bg:"fffff",
    },
    {
        id:3,
        img: "https://cdn.theatlantic.com/thumbor/r7TeaX67Xcx4C5Dof9g93Z9G5lk=/3x314:5998x3686/1600x900/media/img/mt/2019/02/shutterstock_1163044954/original.jpg",
        title: "Refurbished Sale",
        desc: "Nostrud nulla aliquip deserunt deserunt ullamco ex nulla pariatur. Veniam et ea sint reprehenderit quis aute amet incididunt Lorem sunt cupidatat ipsum incididunt eiusmod. Occaecat incididunt incididunt aliqua occaecat enim laborum fugiat voluptate occaecat occaecat amet dolore.",
        bg:"ffffff",
    },
]


  export const categories = [
    {
      id: 1,
      img: "https://images.unsplash.com/photo-1526738549149-8e07eca6c147?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1025&q=80",
      title: "Electronics",
    },
    {
      id: 2,
      img: "https://images.unsplash.com/photo-1561840884-9dda41ed54e4?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      title: "Bicycles",
    },
    {
      id: 3,
      img: "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
      title: "Books and Study Material",
    },
  ];

  export const newProducts = [
    {
      id:1,
      img:"https://www.teahub.io/photos/full/143-1430021_best-wallpapers-for-s9-plus.jpg",
    },
    {
      id:2,
      img:"https://cdn.shopify.com/s/files/1/0101/4832/products/Angela_Natural_Tee.png?v=1606780388",
    },
    {
      id:3,
      img:"https://res.cloudinary.com/trendhim/image/upload/f_auto,c_pad,q_auto,w_1600,h_900/media/catalog/product/1/9/19751-01.jpg",
    },
    {
      id:4,
      img:"https://www.teahub.io/photos/full/184-1843864_omega-constellation-globemaster-annual-calendar-black-omega-2019.jpg",
    },
    {
      id:5,
      img:"https://media3.bosch-home.com/Product_Shots/1600x900/MCSA00726777_E5586_TWK7804_378385_def.png",
    },
    {
      id:6,
      img:"https://cdna.artstation.com/p/assets/images/images/033/821/840/medium/nipun-madusanka-5.jpg?1610648695",
    },
    {
      id:7,
      img:"https://media.cnn.com/api/v1/images/stellar/prod/210429151805-cabaeu-insert-image.jpg?q=w_1600,h_900,x_0,y_0,c_fill",
    },
    {
      id:8,
      img:"https://www.teahub.io/photos/full/342-3426481_computer-keyboard.jpg",
    },
    {
        id:9,
        img:"https://wallpaper.dog/large/17099993.jpg",
    },
  ]